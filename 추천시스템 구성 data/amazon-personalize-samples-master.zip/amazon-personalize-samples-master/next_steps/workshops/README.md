# Amazon Personalize Workshops

This folder contains examples on the following topics:

* POC in a box
* Re:invent 2019 Workshop


## License Summary

This sample code is made available under a modified MIT license. See the LICENSE file.
